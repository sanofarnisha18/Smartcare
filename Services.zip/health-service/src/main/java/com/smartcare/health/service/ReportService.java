package com.smartcare.health.service;

import com.smartcare.health.entity.HealthRecord;
import com.smartcare.health.entity.Report;

import com.smartcare.health.repository.HealthRecordRepository;
import com.smartcare.health.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final HealthRecordRepository healthRecordRepository;
    private final ReportRepository reportRepository;

    public List<HealthRecord> getHealthRecordsByPatient(String patientId) {
        return healthRecordRepository.findByPatientId(patientId);
    }

    public HealthRecord addHealthRecord(HealthRecord record) {
        return healthRecordRepository.save(record);
    }

    public List<Report> getReportsByPatient(String patientId) {
        return reportRepository.findByPatientId(patientId);
    }

    public Report generateReport(Report report) {
        return reportRepository.save(report);
    }
}
