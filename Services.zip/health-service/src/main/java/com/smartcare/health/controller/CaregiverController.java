package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.Caregiver;
import com.smartcare.health.service.CaregiverService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/caregivers")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Caregiver Management API", description = "Endpoints for Caregiver profiles and assignments")
public class CaregiverController {

    private final CaregiverService caregiverService;

    @GetMapping
    @Operation(summary = "Get all caregivers")
    public ResponseEntity<ApiResponse<List<Caregiver>>> getAllCaregivers() {
        return ResponseEntity.ok(ApiResponse.success("Caregivers retrieved", caregiverService.getAllCaregivers()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get caregiver by ID")
    public ResponseEntity<ApiResponse<Caregiver>> getCaregiverById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver details retrieved", caregiverService.getCaregiverById(id)));
    }

    @PostMapping
    @Operation(summary = "Add new caregiver")
    public ResponseEntity<ApiResponse<Caregiver>> addCaregiver(@RequestBody Caregiver caregiver) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver added successfully", caregiverService.addCaregiver(caregiver)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update caregiver")
    public ResponseEntity<ApiResponse<Caregiver>> updateCaregiver(@PathVariable String id, @RequestBody Caregiver caregiver) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver updated successfully", caregiverService.updateCaregiver(id, caregiver)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete caregiver")
    public ResponseEntity<ApiResponse<Void>> deleteCaregiver(@PathVariable String id) {
        caregiverService.deleteCaregiver(id);
        return ResponseEntity.ok(ApiResponse.success("Caregiver deleted", null));
    }
}
