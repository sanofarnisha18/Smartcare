package com.smartcare.health.service;

import com.smartcare.health.entity.Caregiver;
import com.smartcare.health.exception.ResourceNotFoundException;
import com.smartcare.health.repository.CaregiverRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CaregiverService {

    private final CaregiverRepository caregiverRepository;

    public List<Caregiver> getAllCaregivers() {
        return caregiverRepository.findAll();
    }

    public Caregiver getCaregiverById(String id) {
        return caregiverRepository.findById(id)
                .orElseGet(() -> caregiverRepository.findByUserId(id)
                        .orElseThrow(() -> new ResourceNotFoundException("Caregiver not found with ID: " + id)));
    }

    public Caregiver addCaregiver(Caregiver caregiver) {
        if (caregiver.getId() == null) {
            caregiver.setId("caregiver-" + System.currentTimeMillis());
        }
        return caregiverRepository.save(caregiver);
    }

    public Caregiver updateCaregiver(String id, Caregiver patch) {
        Caregiver existing = getCaregiverById(id);
        if (patch.getName() != null) existing.setName(patch.getName());
        if (patch.getSpecialization() != null) existing.setSpecialization(patch.getSpecialization());
        if (patch.getExperience() != null) existing.setExperience(patch.getExperience());
        if (patch.getRating() != null) existing.setRating(patch.getRating());
        if (patch.getAvailability() != null) existing.setAvailability(patch.getAvailability());
        if (patch.getPhone() != null) existing.setPhone(patch.getPhone());
        return caregiverRepository.save(existing);
    }

    public void deleteCaregiver(String id) {
        if (!caregiverRepository.existsById(id)) {
            throw new ResourceNotFoundException("Caregiver not found with ID: " + id);
        }
        caregiverRepository.deleteById(id);
    }
}
