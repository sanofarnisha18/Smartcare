package com.smartcare.health.service;

import com.smartcare.health.entity.Patient;
import com.smartcare.health.exception.ResourceNotFoundException;
import com.smartcare.health.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PatientService {

    private final PatientRepository patientRepository;

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public Patient getPatientById(String id) {
        return patientRepository.findById(id)
                .orElseGet(() -> patientRepository.findByUserId(id)
                        .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id)));
    }

    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public Patient updatePatient(String id, Patient patch) {
        Patient existing = getPatientById(id);

        if (patch.getName() != null) existing.setName(patch.getName());
        if (patch.getAge() != null) existing.setAge(patch.getAge());
        if (patch.getGender() != null) existing.setGender(patch.getGender());
        if (patch.getBloodGroup() != null) existing.setBloodGroup(patch.getBloodGroup());
        if (patch.getPhone() != null) existing.setPhone(patch.getPhone());
        if (patch.getAddress() != null) existing.setAddress(patch.getAddress());
        if (patch.getDisease() != null) existing.setDisease(patch.getDisease());
        if (patch.getMedicalHistory() != null) existing.setMedicalHistory(patch.getMedicalHistory());
        if (patch.getAllergies() != null) existing.setAllergies(patch.getAllergies());
        if (patch.getCurrentMedicines() != null) existing.setCurrentMedicines(patch.getCurrentMedicines());
        if (patch.getEmergencyContact() != null) existing.setEmergencyContact(patch.getEmergencyContact());
        if (patch.getHealthScore() != null) existing.setHealthScore(patch.getHealthScore());
        if (patch.getHeartRate() != null) existing.setHeartRate(patch.getHeartRate());
        if (patch.getBloodPressure() != null) existing.setBloodPressure(patch.getBloodPressure());
        if (patch.getSugarLevel() != null) existing.setSugarLevel(patch.getSugarLevel());
        if (patch.getOxygenLevel() != null) existing.setOxygenLevel(patch.getOxygenLevel());
        if (patch.getAssignedCaretakerId() != null) existing.setAssignedCaretakerId(patch.getAssignedCaretakerId());
        if (patch.getRequestedCaretakerId() != null) existing.setRequestedCaretakerId(patch.getRequestedCaretakerId());

        return patientRepository.save(existing);
    }

    public Patient completeProfile(String id, Patient details) {
        Patient existing = getPatientById(id);
        existing.setDisease(details.getDisease() != null ? details.getDisease() : "General Checkup Required");
        existing.setMedicalHistory(details.getMedicalHistory() != null ? details.getMedicalHistory() : "");
        existing.setAllergies(details.getAllergies() != null ? details.getAllergies() : "None known");
        existing.setCurrentMedicines(details.getCurrentMedicines() != null ? details.getCurrentMedicines() : "");
        existing.setEmergencyContact(details.getEmergencyContact() != null ? details.getEmergencyContact() : existing.getPhone());
        existing.setProfileCompleted(true);
        return patientRepository.save(existing);
    }

    public Patient requestCaregiver(String patientId, String caregiverId) {
        Patient patient = getPatientById(patientId);
        patient.setRequestedCaretakerId(caregiverId);
        return patientRepository.save(patient);
    }

    public Patient assignCaregiver(String patientId, String caregiverId) {
        Patient patient = getPatientById(patientId);
        if (caregiverId == null || caregiverId.trim().isEmpty() || "null".equalsIgnoreCase(caregiverId.trim())) {
            patient.setAssignedCaretakerId(null);
        } else {
            patient.setAssignedCaretakerId(caregiverId);
        }
        patient.setRequestedCaretakerId(null);
        return patientRepository.save(patient);
    }

    public Patient declineCaregiver(String patientId) {
        Patient patient = getPatientById(patientId);
        patient.setRequestedCaretakerId(null);
        return patientRepository.save(patient);
    }

    public Patient markSeenByAdmin(String patientId) {
        Patient patient = getPatientById(patientId);
        patient.setSeenByAdmin(true);
        return patientRepository.save(patient);
    }

    public void deletePatient(String id) {
        if (!patientRepository.existsById(id)) {
            throw new ResourceNotFoundException("Patient not found with ID: " + id);
        }
        patientRepository.deleteById(id);
    }
}
