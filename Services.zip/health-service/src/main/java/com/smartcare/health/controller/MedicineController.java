package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.Medicine;
import com.smartcare.health.entity.Reminder;
import com.smartcare.health.service.MedicineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicines")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Medicine & Reminders API", description = "Endpoints for Medicine tracking, dosage, and schedules")
public class MedicineController {

    private final MedicineService medicineService;

    @GetMapping
    @Operation(summary = "Get all medicines")
    public ResponseEntity<ApiResponse<List<Medicine>>> getAllMedicines() {
        return ResponseEntity.ok(ApiResponse.success("Medicines retrieved", medicineService.getAllMedicines()));
    }

    @GetMapping("/patient/{patientId}")
    @Operation(summary = "Get medicines for specific patient")
    public ResponseEntity<ApiResponse<List<Medicine>>> getMedicinesByPatient(@PathVariable String patientId) {
        return ResponseEntity.ok(ApiResponse.success("Patient medicines retrieved", medicineService.getMedicinesByPatient(patientId)));
    }

    @PostMapping
    @Operation(summary = "Add new medicine schedule")
    public ResponseEntity<ApiResponse<Medicine>> addMedicine(@RequestBody Medicine medicine) {
        return ResponseEntity.ok(ApiResponse.success("Medicine added successfully", medicineService.addMedicine(medicine)));
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "Update medicine status (Taken / Pending)")
    public ResponseEntity<ApiResponse<Medicine>> updateStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success("Medicine status updated", medicineService.updateMedicineStatus(id, status)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete medicine schedule")
    public ResponseEntity<ApiResponse<Void>> deleteMedicine(@PathVariable Long id) {
        medicineService.deleteMedicine(id);
        return ResponseEntity.ok(ApiResponse.success("Medicine deleted", null));
    }

    @GetMapping("/reminders/{patientId}")
    @Operation(summary = "Get medicine reminders for patient")
    public ResponseEntity<ApiResponse<List<Reminder>>> getReminders(@PathVariable String patientId) {
        return ResponseEntity.ok(ApiResponse.success("Reminders retrieved", medicineService.getRemindersByPatient(patientId)));
    }
}
