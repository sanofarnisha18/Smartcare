package com.smartcare.auth.service;

import com.smartcare.auth.dto.UserDto;
import com.smartcare.auth.entity.User;
import com.smartcare.auth.exception.ResourceNotFoundException;
import com.smartcare.auth.repository.UserRepository;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    private final AuthService authService;


    // Get All Users
    public List<UserDto> getAllUsers() {

        return userRepository.findAll()
                .stream()
                .map(authService::mapToUserDto)
                .collect(Collectors.toList());
    }


    // Get User By ID
    public UserDto getUserById(String id) {

        User user = userRepository
                .findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + id
                        )
                );

        return authService.mapToUserDto(user);
    }


    // Get User By Email
    public UserDto getUserByEmail(String email) {

        User user = userRepository
                .findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with email: " + email
                        )
                );

        return authService.mapToUserDto(user);
    }


    // Get Users By Role
    public List<UserDto> getUsersByRole(String role) {

        return userRepository
                .findByRole(role.toLowerCase())
                .stream()
                .map(authService::mapToUserDto)
                .collect(Collectors.toList());
    }


    // Update User
    public UserDto updateUser(
            String id,
            UserDto dto
    ) {

        User user = userRepository
                .findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + id
                        )
                );


        if (dto.getName() != null)
            user.setName(dto.getName());


        if (dto.getPhone() != null)
            user.setPhone(dto.getPhone());


        if (dto.getAge() != null)
            user.setAge(dto.getAge());


        if (dto.getGender() != null)
            user.setGender(dto.getGender());


        if (dto.getPhoto() != null)
            user.setPhoto(dto.getPhoto());


        if (dto.getProfileCompleted() != null)
            user.setProfileCompleted(
                    dto.getProfileCompleted()
            );


        User updated = userRepository.save(user);

        return authService.mapToUserDto(updated);
    }


    // Delete User
    @Transactional
    public void deleteUser(String id) {

        User user = userRepository
                .findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "User not found with id: " + id
                        )
                );

        // Soft delete the user so that login fails with a specific message
        user.setEnabled(false);
        user.getRefreshTokens().clear();
        userRepository.save(user);
    }
}