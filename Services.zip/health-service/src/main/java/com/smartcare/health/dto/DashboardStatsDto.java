package com.smartcare.health.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDto {

    private long totalPatients;
    private long totalCaregivers;
    private long pendingAppointments;
    private long confirmedAppointments;
    private long activeMedicines;
    private long totalEmergencyAlerts;
    private long unreadMessages;
}
