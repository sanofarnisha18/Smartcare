package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "health_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HealthRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "patient_id", nullable = false, length = 100)
    private String patientId;

    @Column(nullable = false)
    private String recordType; // Vitals Check, Diagnostic, Quarterly Summary

    private String heartRate;

    private String bloodPressure;

    private String sugarLevel;

    private String oxygenLevel;

    @Column(columnDefinition = "TEXT")
    private String description;

    private LocalDateTime recordDate;

    @PrePersist
    protected void onCreate() {
        this.recordDate = LocalDateTime.now();
    }
}
