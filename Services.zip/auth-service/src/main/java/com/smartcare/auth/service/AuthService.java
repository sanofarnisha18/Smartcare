package com.smartcare.auth.service;

import com.smartcare.auth.dto.*;
import com.smartcare.auth.entity.RefreshToken;
import com.smartcare.auth.entity.User;
import com.smartcare.auth.exception.BadRequestException;
import com.smartcare.auth.exception.ResourceNotFoundException;
import com.smartcare.auth.repository.RefreshTokenRepository;
import com.smartcare.auth.repository.UserRepository;
import com.smartcare.auth.security.JwtTokenProvider;

import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;


@Service
@RequiredArgsConstructor
public class AuthService {


    private final UserRepository userRepository;

    private final RefreshTokenRepository refreshTokenRepository;

    private final PasswordEncoder passwordEncoder;

    private final JwtTokenProvider tokenProvider;



    // ================= REGISTER =================

    public AuthResponse register(RegisterRequest request) {


        if(userRepository.existsById(
                request.getEmail().trim().toLowerCase()
        )) {

            throw new BadRequestException(
                    "An account with this email already exists."
            );
        }



        String userId = "patient-" + System.currentTimeMillis();



        User user = User.builder()

                .id(userId)

                .email(
                    request.getEmail()
                    .trim()
                    .toLowerCase()
                )

                .password(
                    passwordEncoder.encode(
                        request.getPassword()
                    )
                )

                .name(
                    request.getName().trim()
                )

                .phone(
                    request.getPhone()!=null
                    ? request.getPhone()
                    : "9876543210"
                )

                .role("patient")

                .age(
                    request.getAge()!=null
                    ? request.getAge()
                    : 65
                )

                .gender(
                    request.getGender()!=null
                    ? request.getGender()
                    : "Male"
                )

                .profileCompleted(false)

                .build();



        User savedUser = userRepository.save(user);



        // JWT TOKEN
        String token = tokenProvider.generateToken(
                savedUser.getEmail(),
                savedUser.getRole()
        );



        RefreshToken refreshToken =
                createRefreshToken(savedUser);



        return AuthResponse.builder()

                .token(token)

                .refreshToken(
                    refreshToken.getToken()
                )

                .user(
                    mapToUserDto(savedUser)
                )

                .build();

    }




    // ================= LOGIN =================


    public AuthResponse login(LoginRequest request) {


        User user =
                userRepository.findByEmail(
                    request.getEmail()
                    .trim()
                    .toLowerCase()
                )

                .orElseThrow(
                    () -> new BadRequestException(
                        "Invalid email or password."
                    )
                );

        if (user.getEnabled() != null && !user.getEnabled()) {
            throw new BadRequestException("This account has been deleted. Please contact the administrator.");
        }



        boolean matches =
                passwordEncoder.matches(
                    request.getPassword(),
                    user.getPassword()
                );



        if(!matches){

            throw new BadRequestException(
                    "Invalid email or password."
            );

        }



        String token = tokenProvider.generateToken(
                user.getEmail(),
                user.getRole()
        );



        RefreshToken refreshToken =
                createRefreshToken(user);



        return AuthResponse.builder()

                .token(token)

                .refreshToken(
                    refreshToken.getToken()
                )

                .user(
                    mapToUserDto(user)
                )

                .build();

    }





    // ================= FORGOT PASSWORD =================


    public ApiResponse<Void> forgotPassword(
            ForgotPasswordRequest request) {


        User user =
                userRepository.findByEmail(
                    request.getEmail()
                    .trim()
                    .toLowerCase()
                )

                .orElseThrow(
                    () -> new ResourceNotFoundException(
                        "No account found with this email address."
                    )
                );



        return ApiResponse.success(
                "Password reset instructions sent to "
                + user.getEmail(),
                null
        );

    }





    // ================= RESET PASSWORD =================


    public ApiResponse<Void> resetPassword(
            ResetPasswordRequest request) {



        User user =
                userRepository.findByEmail(
                    request.getEmail()
                    .trim()
                    .toLowerCase()
                )

                .orElseThrow(
                    () -> new ResourceNotFoundException(
                        "No account found with this email address."
                    )
                );



        user.setPassword(
                passwordEncoder.encode(
                    request.getNewPassword()
                )
        );


        userRepository.save(user);



        return ApiResponse.success(
                "Password reset successfully!",
                null
        );

    }





    // ================= REFRESH TOKEN =================


    public AuthResponse refreshToken(
            RefreshTokenRequest request) {



        RefreshToken token =
                refreshTokenRepository.findByToken(
                    request.getRefreshToken()
                )

                .orElseThrow(
                    () -> new BadRequestException(
                        "Invalid refresh token"
                    )
                );



        if(
            token.getExpiryDate()
            .isBefore(Instant.now())

            ||
            
            token.getRevoked()
        ){

            refreshTokenRepository.delete(token);


            throw new BadRequestException(
                    "Refresh token expired or revoked"
            );

        }



        User user = token.getUser();

        if (user.getEnabled() != null && !user.getEnabled()) {
            throw new BadRequestException("This account has been deleted. Please contact the administrator.");
        }



        String newToken =
                tokenProvider.generateToken(
                    user.getEmail(),
                    user.getRole()
                );



        return AuthResponse.builder()

                .token(newToken)

                .refreshToken(
                    token.getToken()
                )

                .user(
                    mapToUserDto(user)
                )

                .build();

    }





    // ================= CREATE REFRESH TOKEN =================


    public RefreshToken createRefreshToken(
            User user) {


        RefreshToken refreshToken =
                RefreshToken.builder()

                .user(user)

                .token(
                    UUID.randomUUID()
                    .toString()
                )

                .expiryDate(
                    Instant.now()
                    .plusMillis(604800000)
                )

                .revoked(false)

                .build();



        return refreshTokenRepository.save(
                refreshToken
        );

    }





    // ================= USER DTO =================


    public UserDto mapToUserDto(
            User user) {


        return UserDto.builder()

                .id(user.getId())

                .email(user.getEmail())

                .name(user.getName())

                .role(user.getRole())

                .phone(user.getPhone())

                .age(user.getAge())

                .gender(user.getGender())

                .photo(user.getPhoto())

                .profileCompleted(
                    user.getProfileCompleted()
                )

                .build();

    }


    // ================= ADMIN CREATE CAREGIVER =================

    public UserDto adminCreateCaregiver(RegisterRequest request) {

        if(userRepository.existsById(
                request.getEmail().trim().toLowerCase()
        )) {
            throw new BadRequestException(
                    "An account with this email already exists."
            );
        }

        String userId = "caregiver-" + System.currentTimeMillis();

        User user = User.builder()
                .id(userId)
                .email(request.getEmail().trim().toLowerCase())
                .password(passwordEncoder.encode(request.getPassword()))
                .name(request.getName().trim())
                .phone(request.getPhone() != null ? request.getPhone() : "9876543210")
                .role("caregiver")
                .age(request.getAge() != null ? request.getAge() : 35)
                .gender(request.getGender() != null ? request.getGender() : "Male")
                .profileCompleted(true)
                .build();

        User savedUser = userRepository.save(user);

        return mapToUserDto(savedUser);
    }

}