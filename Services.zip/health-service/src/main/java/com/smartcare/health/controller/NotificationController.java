package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.Notification;
import com.smartcare.health.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Notifications & Messaging API", description = "Endpoints for real-time messaging, notifications, and unread counts")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping("/send")
    @Operation(summary = "Send a message or notification")
    public ResponseEntity<ApiResponse<Notification>> sendMessage(
            @RequestParam String senderId,
            @RequestParam(required = false, defaultValue = "User") String senderName,
            @RequestParam String receiverId,
            @RequestParam(required = false, defaultValue = "User") String receiverName,
            @RequestParam String content) {
        Notification notification = notificationService.sendMessage(senderId, senderName, receiverId, receiverName, content);
        return ResponseEntity.ok(ApiResponse.success("Message sent successfully", notification));
    }

    @GetMapping("/conversation")
    @Operation(summary = "Get full conversation between two users")
    public ResponseEntity<ApiResponse<List<Notification>>> getConversation(
            @RequestParam String userId,
            @RequestParam String otherId) {
        return ResponseEntity.ok(ApiResponse.success("Conversation retrieved", notificationService.getConversation(userId, otherId)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all notifications for a user")
    public ResponseEntity<ApiResponse<List<Notification>>> getUserNotifications(@PathVariable String userId) {
        return ResponseEntity.ok(ApiResponse.success("User notifications retrieved", notificationService.getUserNotifications(userId)));
    }

    @GetMapping("/unread-count/{userId}")
    @Operation(summary = "Get total unread message count for a user")
    public ResponseEntity<ApiResponse<Integer>> getUnreadCount(@PathVariable String userId) {
        return ResponseEntity.ok(ApiResponse.success("Unread count", notificationService.getUnreadCount(userId)));
    }

    @GetMapping("/unread-count-from")
    @Operation(summary = "Get unread message count from a specific sender")
    public ResponseEntity<ApiResponse<Integer>> getUnreadCountFrom(
            @RequestParam String userId,
            @RequestParam String otherId) {
        return ResponseEntity.ok(ApiResponse.success("Unread count from user", notificationService.getUnreadFrom(userId, otherId)));
    }

    @PostMapping("/mark-read")
    @Operation(summary = "Mark conversation read between users")
    public ResponseEntity<ApiResponse<Void>> markConversationRead(
            @RequestParam String userId,
            @RequestParam String otherId) {
        notificationService.markConversationRead(userId, otherId);
        return ResponseEntity.ok(ApiResponse.success("Conversation marked as read", null));
    }
}
