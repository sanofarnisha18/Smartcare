package com.smartcare.auth.controller;

import com.smartcare.auth.dto.*;
import com.smartcare.auth.entity.User;
import com.smartcare.auth.service.AuthService;
import com.smartcare.auth.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
@Tag(
        name = "Authentication Service",
        description = "Authentication APIs"
)
public class AuthController {


    private final AuthService authService;
    private final UserService userService;


    public AuthController(
            AuthService authService,
            UserService userService
    ) {
        this.authService = authService;
        this.userService = userService;
    }



    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody RegisterRequest request
    ){

        AuthResponse response =
                authService.register(request);


        return ResponseEntity.ok(
                ApiResponse.success(
                        "User registered successfully",
                        response
                )
        );
    }




    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request
    ){

        AuthResponse response =
                authService.login(request);


        return ResponseEntity.ok(
                ApiResponse.success(
                        "Login successful",
                        response
                )
        );
    }





    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<Void>> forgotPassword(
            @Valid @RequestBody ForgotPasswordRequest request
    ){

        return ResponseEntity.ok(
                authService.forgotPassword(request)
        );
    }





    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<Void>> resetPassword(
            @Valid @RequestBody ResetPasswordRequest request
    ){

        return ResponseEntity.ok(
                authService.resetPassword(request)
        );
    }





    @PostMapping("/refresh-token")
    public ResponseEntity<ApiResponse<AuthResponse>> refreshToken(
            @Valid @RequestBody RefreshTokenRequest request
    ){

        AuthResponse response =
                authService.refreshToken(request);


        return ResponseEntity.ok(
                ApiResponse.success(
                        "Token refreshed successfully",
                        response
                )
        );
    }





    @GetMapping("/me")
    @Operation(summary = "Get Current User")
    public ResponseEntity<ApiResponse<UserDto>> getCurrentUser(
            Authentication authentication
    ){


        if(authentication == null){

            return ResponseEntity
                    .status(401)
                    .body(
                        ApiResponse.error(
                            "Unauthorized"
                        )
                    );
        }



        User user =
                (User) authentication.getPrincipal();



        UserDto userDto =
                userService.getUserByEmail(
                        user.getEmail()
                );



        return ResponseEntity.ok(
                ApiResponse.success(
                        "Current user profile retrieved",
                        userDto
                )
        );

    }


    @PostMapping("/admin/create-caregiver")
    @Operation(summary = "Admin create caregiver")
    public ResponseEntity<ApiResponse<UserDto>> adminCreateCaregiver(
            @Valid @RequestBody RegisterRequest request
    ){
        UserDto userDto = authService.adminCreateCaregiver(request);
        return ResponseEntity.ok(
                ApiResponse.success(
                        "Caregiver created successfully",
                        userDto
                )
        );
    }

}