package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "notifications")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification {

    @Id
    @Column(length = 100)
    private String id;

    @Column(nullable = false, length = 100)
    private String senderId;

    private String senderName;

    @Column(nullable = false, length = 100)
    private String receiverId;

    private String receiverName;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    @Builder.Default
    private Boolean isRead = false;

    private String timestamp;

    private Long createdAt;

    @PrePersist
    protected void onCreate() {
        if (this.id == null) {
            this.id = "msg-" + System.currentTimeMillis();
        }
        if (this.createdAt == null) {
            this.createdAt = System.currentTimeMillis();
        }
        if (this.isRead == null) {
            this.isRead = false;
        }
    }
}
