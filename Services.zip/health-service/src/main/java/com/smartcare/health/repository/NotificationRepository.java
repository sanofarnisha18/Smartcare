package com.smartcare.health.repository;

import com.smartcare.health.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, String> {

    @Query("SELECT n FROM Notification n WHERE (n.senderId = :user1 AND n.receiverId = :user2) OR (n.senderId = :user2 AND n.receiverId = :user1) ORDER BY n.createdAt ASC")
    List<Notification> findConversation(@Param("user1") String user1, @Param("user2") String user2);

    List<Notification> findByReceiverId(String receiverId);

    List<Notification> findByReceiverIdAndIsReadFalse(String receiverId);

    List<Notification> findByReceiverIdAndSenderIdAndIsReadFalse(String receiverId, String senderId);
}
