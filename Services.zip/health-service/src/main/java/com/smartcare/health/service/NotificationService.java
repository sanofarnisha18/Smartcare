package com.smartcare.health.service;

import com.smartcare.health.entity.Notification;
import com.smartcare.health.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public Notification sendMessage(String senderId, String senderName, String receiverId, String receiverName, String content) {
        String formattedTime = LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a"));
        Notification notification = Notification.builder()
                .id("msg-" + System.currentTimeMillis())
                .senderId(senderId)
                .senderName(senderName)
                .receiverId(receiverId)
                .receiverName(receiverName)
                .content(content)
                .isRead(false)
                .timestamp(formattedTime)
                .createdAt(System.currentTimeMillis())
                .build();
        return notificationRepository.save(notification);
    }

    public List<Notification> getConversation(String userId, String otherId) {
        return notificationRepository.findConversation(userId, otherId);
    }

    public List<Notification> getUserNotifications(String userId) {
        return notificationRepository.findByReceiverId(userId);
    }

    public int getUnreadCount(String userId) {
        return notificationRepository.findByReceiverIdAndIsReadFalse(userId).size();
    }

    public int getUnreadFrom(String userId, String otherId) {
        return notificationRepository.findByReceiverIdAndSenderIdAndIsReadFalse(userId, otherId).size();
    }

    public void markConversationRead(String userId, String otherId) {
        List<Notification> unread = notificationRepository.findByReceiverIdAndSenderIdAndIsReadFalse(userId, otherId);
        unread.forEach(n -> n.setIsRead(true));
        notificationRepository.saveAll(unread);
    }
}
