package com.smartcare.auth.security;


import com.smartcare.auth.entity.User;
import com.smartcare.auth.repository.UserRepository;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;


import java.io.IOException;



@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {


    private final JwtTokenProvider tokenProvider;

    private final UserRepository userRepository;



    public JwtAuthenticationFilter(
            JwtTokenProvider tokenProvider,
            UserRepository userRepository
    ){

        this.tokenProvider = tokenProvider;
        this.userRepository = userRepository;

    }





    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    )
            throws ServletException, IOException {


        System.out.println(
                "REQUEST = " + request.getRequestURI()
        );


        String authHeader =
                request.getHeader("Authorization");


        System.out.println(
                "AUTH HEADER = " + authHeader
        );



        String token = null;
        String email = null;



        if(authHeader != null &&
                authHeader.startsWith("Bearer ")) {


            token =
                    authHeader.substring(7);


            try {


                email =
                    tokenProvider
                    .getEmailFromToken(token);


                System.out.println(
                        "EMAIL = " + email
                );


            }
            catch(Exception e){

                System.out.println(
                        "JWT ERROR = " + e.getMessage()
                );

            }

        }





        if(email != null &&
                SecurityContextHolder
                .getContext()
                .getAuthentication()
                == null) {



            User user =
                    userRepository
                    .findByEmail(email)
                    .orElse(null);




            if(user != null &&
               (user.getEnabled() == null || user.getEnabled()) &&
               tokenProvider.validateToken(token)) {



                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(
                                user,
                                null,
                                user.getAuthorities()
                        );



                authentication.setDetails(
                        new WebAuthenticationDetailsSource()
                        .buildDetails(request)
                );



                SecurityContextHolder
                        .getContext()
                        .setAuthentication(authentication);



                System.out.println(
                        "JWT AUTH SUCCESS"
                );

            }

        }




        filterChain.doFilter(
                request,
                response
        );

    }

}