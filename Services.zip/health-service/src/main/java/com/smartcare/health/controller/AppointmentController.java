package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.Appointment;
import com.smartcare.health.service.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Appointment Management API", description = "Endpoints for scheduling and managing doctor appointments")
public class AppointmentController {

    private final AppointmentService appointmentService;

    @GetMapping
    @Operation(summary = "Get all appointments")
    public ResponseEntity<ApiResponse<List<Appointment>>> getAllAppointments() {
        return ResponseEntity.ok(ApiResponse.success("Appointments retrieved", appointmentService.getAllAppointments()));
    }

    @GetMapping("/patient/{patientId}")
    @Operation(summary = "Get appointments by patient ID")
    public ResponseEntity<ApiResponse<List<Appointment>>> getAppointmentsByPatient(@PathVariable String patientId) {
        return ResponseEntity.ok(ApiResponse.success("Patient appointments retrieved", appointmentService.getAppointmentsByPatient(patientId)));
    }

    @PostMapping
    @Operation(summary = "Create appointment")
    public ResponseEntity<ApiResponse<Appointment>> createAppointment(@RequestBody Appointment appointment) {
        return ResponseEntity.ok(ApiResponse.success("Appointment created successfully", appointmentService.createAppointment(appointment)));
    }

    @PutMapping("/{id}/status")
    @Operation(summary = "Update appointment status (Confirmed / Cancelled)")
    public ResponseEntity<ApiResponse<Appointment>> updateStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success("Appointment status updated", appointmentService.updateAppointmentStatus(id, status)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete appointment")
    public ResponseEntity<ApiResponse<Void>> deleteAppointment(@PathVariable Long id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.ok(ApiResponse.success("Appointment deleted", null));
    }
}
