package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "caregivers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Caregiver {

    @Id
    @Column(length = 100)
    private String id;

    @Column(name = "user_id", nullable = false, length = 100)
    private String userId;

    private String name;

    private String specialization;

    private String experience;

    private Double rating;

    private String availability;

    private String phone;
}
