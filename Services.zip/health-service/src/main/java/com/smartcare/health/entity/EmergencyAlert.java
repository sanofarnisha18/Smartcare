package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "emergency_alerts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmergencyAlert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "patient_id", nullable = false, length = 100)
    private String patientId;

    private String patientName;

    private String caregiverId;

    @Builder.Default
    private String alertType = "SOS Emergency";

    @Builder.Default
    private String status = "ACTIVE"; // ACTIVE, RESOLVED

    private String location;

    private LocalDateTime triggeredAt;

    @PrePersist
    protected void onCreate() {
        this.triggeredAt = LocalDateTime.now();
        if (this.status == null) this.status = "ACTIVE";
    }
}
