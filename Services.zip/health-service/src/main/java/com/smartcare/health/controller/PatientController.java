package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.Patient;
import com.smartcare.health.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Patient Management API", description = "CRUD and workflow endpoints for Patient Management")
public class PatientController {

    private final PatientService patientService;

    @GetMapping
    @Operation(summary = "Get all patients")
    public ResponseEntity<ApiResponse<List<Patient>>> getAllPatients() {
        return ResponseEntity.ok(ApiResponse.success("Patients retrieved successfully", patientService.getAllPatients()));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get patient by ID")
    public ResponseEntity<ApiResponse<Patient>> getPatientById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Patient details retrieved", patientService.getPatientById(id)));
    }

    @PostMapping
    @Operation(summary = "Create or save patient")
    public ResponseEntity<ApiResponse<Patient>> createPatient(@RequestBody Patient patient) {
        return ResponseEntity.ok(ApiResponse.success("Patient created successfully", patientService.savePatient(patient)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update patient details")
    public ResponseEntity<ApiResponse<Patient>> updatePatient(@PathVariable String id, @RequestBody Patient patient) {
        return ResponseEntity.ok(ApiResponse.success("Patient updated successfully", patientService.updatePatient(id, patient)));
    }

    @PostMapping("/{id}/complete-profile")
    @Operation(summary = "Complete first-login medical profile")
    public ResponseEntity<ApiResponse<Patient>> completeProfile(@PathVariable String id, @RequestBody Patient details) {
        return ResponseEntity.ok(ApiResponse.success("Profile completed", patientService.completeProfile(id, details)));
    }

    @PostMapping("/{id}/request-caregiver")
    @Operation(summary = "Request caregiver for patient")
    public ResponseEntity<ApiResponse<Patient>> requestCaregiver(@PathVariable String id, @RequestParam String caregiverId) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver requested", patientService.requestCaregiver(id, caregiverId)));
    }

    @PostMapping("/{id}/assign-caregiver")
    @Operation(summary = "Assign caregiver to patient")
    public ResponseEntity<ApiResponse<Patient>> assignCaregiver(@PathVariable String id, @RequestParam(required = false) String caregiverId) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver assigned", patientService.assignCaregiver(id, caregiverId)));
    }

    @PostMapping("/{id}/decline-caregiver")
    @Operation(summary = "Decline caregiver request")
    public ResponseEntity<ApiResponse<Patient>> declineCaregiver(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Caregiver request declined", patientService.declineCaregiver(id)));
    }

    @PostMapping("/{id}/mark-seen")
    @Operation(summary = "Mark patient profile seen by Admin")
    public ResponseEntity<ApiResponse<Patient>> markSeen(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.success("Patient marked as seen", patientService.markSeenByAdmin(id)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete patient")
    public ResponseEntity<ApiResponse<Void>> deletePatient(@PathVariable String id) {
        patientService.deletePatient(id);
        return ResponseEntity.ok(ApiResponse.success("Patient deleted", null));
    }
}
