package com.smartcare.auth;

import com.smartcare.auth.entity.User;
import com.smartcare.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AdminSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        String adminEmail = "admin@smartcare.com";
        java.util.Optional<User> existing = userRepository.findByEmail(adminEmail);
        if (existing.isPresent()) {
            System.out.println("Admin account already exists. Skipping default seed.");
        } else {
            User admin = User.builder()
                    .id("admin-1")
                    .email(adminEmail)
                    .password(passwordEncoder.encode("admin123"))
                    .name("System Admin")
                    .phone("9876543210")
                    .role("admin")
                    .age(40)
                    .gender("Male")
                    .profileCompleted(true)
                    .build();
            userRepository.save(admin);
            System.out.println("Seeded default admin account: admin@smartcare.com / admin123");
        }
    }
}
