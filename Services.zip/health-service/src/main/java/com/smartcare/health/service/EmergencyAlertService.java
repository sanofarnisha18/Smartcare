package com.smartcare.health.service;

import com.smartcare.health.entity.EmergencyAlert;
import com.smartcare.health.entity.Patient;
import com.smartcare.health.repository.EmergencyAlertRepository;
import com.smartcare.health.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmergencyAlertService {

    private final EmergencyAlertRepository emergencyAlertRepository;
    private final PatientRepository patientRepository;

    public EmergencyAlert triggerEmergencySos(String patientId, String location) {
        Patient patient = patientRepository.findById(patientId).orElse(null);
        String patientName = patient != null ? patient.getName() : "Unknown Patient";
        String caregiverId = patient != null ? patient.getAssignedCaretakerId() : null;

        EmergencyAlert alert = EmergencyAlert.builder()
                .patientId(patientId)
                .patientName(patientName)
                .caregiverId(caregiverId)
                .alertType("SOS Emergency Alert")
                .status("ACTIVE")
                .location(location != null ? location : "Current GPS Location Shared")
                .build();

        return emergencyAlertRepository.save(alert);
    }

    public List<EmergencyAlert> getAllAlerts() {
        return emergencyAlertRepository.findAll();
    }

    public List<EmergencyAlert> getAlertsByPatient(String patientId) {
        return emergencyAlertRepository.findByPatientId(patientId);
    }

    public long getActiveSosCount() {
        return emergencyAlertRepository.findByStatus("ACTIVE").size();
    }

    public EmergencyAlert resolveAlert(Long id) {
        EmergencyAlert alert = emergencyAlertRepository.findById(id).orElseThrow();
        alert.setStatus("RESOLVED");
        return emergencyAlertRepository.save(alert);
    }
}
