package com.smartcare.health.service;

import com.smartcare.health.dto.DashboardStatsDto;
import com.smartcare.health.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final PatientRepository patientRepository;
    private final CaregiverRepository caregiverRepository;
    private final AppointmentRepository appointmentRepository;
    private final MedicineRepository medicineRepository;
    private final EmergencyAlertRepository emergencyAlertRepository;

    public DashboardStatsDto getDashboardStats() {
        long totalPatients = patientRepository.count();
        long totalCaregivers = caregiverRepository.count();
        long pendingAppointments = appointmentRepository.findAll().stream()
                .filter(a -> "Pending".equalsIgnoreCase(a.getStatus())).count();
        long confirmedAppointments = appointmentRepository.findAll().stream()
                .filter(a -> "Confirmed".equalsIgnoreCase(a.getStatus())).count();
        long activeMedicines = medicineRepository.count();
        long totalEmergencyAlerts = emergencyAlertRepository.count();

        return DashboardStatsDto.builder()
                .totalPatients(totalPatients)
                .totalCaregivers(totalCaregivers)
                .pendingAppointments(pendingAppointments)
                .confirmedAppointments(confirmedAppointments)
                .activeMedicines(activeMedicines)
                .totalEmergencyAlerts(totalEmergencyAlerts)
                .build();
    }
}
