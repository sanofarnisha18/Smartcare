package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "medicines")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Medicine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String dosage;

    @Column(nullable = false)
    private String time; // Morning, Afternoon, Night

    @Column(name = "patient_id", nullable = false, length = 100)
    private String patientId;

    private String patientName;

    @Builder.Default
    private String status = "Pending"; // Pending, Taken

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) this.status = "Pending";
    }
}
