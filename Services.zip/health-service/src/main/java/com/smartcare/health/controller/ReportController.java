package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.HealthRecord;
import com.smartcare.health.entity.Report;
import com.smartcare.health.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Health Records & Reports API", description = "Endpoints for medical history, health logs, and generated reports")
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/records/{patientId}")
    @Operation(summary = "Get health vitals and medical history records for a patient")
    public ResponseEntity<ApiResponse<List<HealthRecord>>> getHealthRecords(@PathVariable String patientId) {
        return ResponseEntity.ok(ApiResponse.success("Health records retrieved", reportService.getHealthRecordsByPatient(patientId)));
    }

    @PostMapping("/records")
    @Operation(summary = "Add a new health vital record log")
    public ResponseEntity<ApiResponse<HealthRecord>> addHealthRecord(@RequestBody HealthRecord record) {
        return ResponseEntity.ok(ApiResponse.success("Health record logged", reportService.addHealthRecord(record)));
    }

    @GetMapping("/patient/{patientId}")
    @Operation(summary = "Get generated medical reports for patient")
    public ResponseEntity<ApiResponse<List<Report>>> getReports(@PathVariable String patientId) {
        return ResponseEntity.ok(ApiResponse.success("Reports retrieved", reportService.getReportsByPatient(patientId)));
    }

    @PostMapping("/generate")
    @Operation(summary = "Generate a new report for patient")
    public ResponseEntity<ApiResponse<Report>> generateReport(@RequestBody Report report) {
        return ResponseEntity.ok(ApiResponse.success("Report generated", reportService.generateReport(report)));
    }
}
