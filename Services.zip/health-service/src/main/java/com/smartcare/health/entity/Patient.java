package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "patients")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Patient {

    @Id
    @Column(length = 100)
    private String id;

    @Column(name = "user_id", nullable = false, length = 100)
    private String userId;

    @Column(nullable = false, length = 150)
    private String name;

    private Integer age;

    private String gender;

    private String bloodGroup;

    private String phone;

    @Column(columnDefinition = "TEXT")
    private String address;

    private String disease;

    @Column(columnDefinition = "TEXT")
    private String medicalHistory;

    private String allergies;

    private String currentMedicines;

    private String emergencyContact;

    private Integer healthScore;

    private String heartRate;

    private String bloodPressure;

    private String sugarLevel;

    private String oxygenLevel;

    private String assignedCaretakerId;

    private String requestedCaretakerId;

    @Builder.Default
    private Boolean profileCompleted = false;

    @Builder.Default
    private Boolean seenByAdmin = false;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.healthScore == null) this.healthScore = 80;
        if (this.heartRate == null) this.heartRate = "76 BPM";
        if (this.bloodPressure == null) this.bloodPressure = "120/80";
        if (this.sugarLevel == null) this.sugarLevel = "100 mg/dL";
        if (this.oxygenLevel == null) this.oxygenLevel = "98%";
    }
}
