package com.smartcare.health.service;

import com.smartcare.health.entity.Medicine;
import com.smartcare.health.entity.Reminder;
import com.smartcare.health.exception.ResourceNotFoundException;
import com.smartcare.health.repository.MedicineRepository;
import com.smartcare.health.repository.ReminderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MedicineService {

    private final MedicineRepository medicineRepository;
    private final ReminderRepository reminderRepository;

    public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

    public List<Medicine> getMedicinesByPatient(String patientId) {
        return medicineRepository.findByPatientId(patientId);
    }

    public Medicine getMedicineById(Long id) {
        return medicineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found with ID: " + id));
    }

    public Medicine addMedicine(Medicine medicine) {
        Medicine saved = medicineRepository.save(medicine);

        // Auto-create reminder schedule
        String defaultTime = "Morning".equalsIgnoreCase(medicine.getTime()) ? "08:00 AM" :
                "Afternoon".equalsIgnoreCase(medicine.getTime()) ? "02:00 PM" : "08:00 PM";

        Reminder reminder = Reminder.builder()
                .patientId(medicine.getPatientId())
                .medicineId(saved.getId())
                .reminderTime(defaultTime)
                .isActive(true)
                .message("Time to take " + medicine.getName())
                .build();
        reminderRepository.save(reminder);

        return saved;
    }

    public Medicine updateMedicineStatus(Long id, String status) {
        Medicine existing = getMedicineById(id);
        existing.setStatus(status);
        return medicineRepository.save(existing);
    }

    public void deleteMedicine(Long id) {
        if (!medicineRepository.existsById(id)) {
            throw new ResourceNotFoundException("Medicine not found with ID: " + id);
        }
        medicineRepository.deleteById(id);
    }

    public List<Reminder> getRemindersByPatient(String patientId) {
        return reminderRepository.findByPatientId(patientId);
    }
}
