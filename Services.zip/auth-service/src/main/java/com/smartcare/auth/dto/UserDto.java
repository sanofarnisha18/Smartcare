package com.smartcare.auth.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private String id;
    private String email;
    private String name;
    private String role;
    private String phone;
    private Integer age;
    private String gender;
    private String photo;
    private Boolean profileCompleted;
}
