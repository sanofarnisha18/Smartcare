package com.smartcare.health.controller;

import com.smartcare.health.dto.ApiResponse;
import com.smartcare.health.entity.EmergencyAlert;
import com.smartcare.health.service.EmergencyAlertService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emergency-alerts")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
@Tag(name = "Emergency SOS & Alerts API", description = "Endpoints for triggering and managing Emergency SOS alerts")
public class EmergencyAlertController {

    private final EmergencyAlertService emergencyAlertService;

    @PostMapping("/trigger")
    @Operation(summary = "Trigger emergency SOS alert")
    public ResponseEntity<ApiResponse<EmergencyAlert>> triggerSos(@RequestParam String patientId, @RequestParam(required = false) String location) {
        EmergencyAlert alert = emergencyAlertService.triggerEmergencySos(patientId, location);
        return ResponseEntity.ok(ApiResponse.success("Emergency SOS Alert triggered successfully!", alert));
    }

    @GetMapping
    @Operation(summary = "Get all emergency alerts")
    public ResponseEntity<ApiResponse<List<EmergencyAlert>>> getAllAlerts() {
        return ResponseEntity.ok(ApiResponse.success("Emergency alerts retrieved", emergencyAlertService.getAllAlerts()));
    }

    @GetMapping("/count")
    @Operation(summary = "Get count of active SOS emergency alerts")
    public ResponseEntity<ApiResponse<Long>> getActiveCount() {
        return ResponseEntity.ok(ApiResponse.success("Active SOS count", emergencyAlertService.getActiveSosCount()));
    }

    @PutMapping("/{id}/resolve")
    @Operation(summary = "Resolve emergency alert")
    public ResponseEntity<ApiResponse<EmergencyAlert>> resolveAlert(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Alert marked resolved", emergencyAlertService.resolveAlert(id)));
    }
}
