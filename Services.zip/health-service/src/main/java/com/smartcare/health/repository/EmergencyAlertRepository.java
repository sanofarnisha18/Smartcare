package com.smartcare.health.repository;

import com.smartcare.health.entity.EmergencyAlert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmergencyAlertRepository extends JpaRepository<EmergencyAlert, Long> {
    List<EmergencyAlert> findByPatientId(String patientId);
    List<EmergencyAlert> findByStatus(String status);
}
