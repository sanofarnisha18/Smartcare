package com.smartcare.health.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "appointments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "patient_id", nullable = false, length = 100)
    private String patientId;

    private String patientName;

    @Column(nullable = false)
    private String doctor;

    @Column(name = "appointment_date", nullable = false)
    private String date;

    @Column(name = "appointment_time", nullable = false)
    private String time;

    @Builder.Default
    private String status = "Pending"; // Pending, Confirmed, Cancelled

    @Column(columnDefinition = "TEXT")
    private String notes;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) this.status = "Pending";
    }
}
