package com.smartcare.health.repository;

import com.smartcare.health.entity.Caregiver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CaregiverRepository extends JpaRepository<Caregiver, String> {
    Optional<Caregiver> findByUserId(String userId);
}
